// BHD Films — one-time helper to get a Google Drive refresh token.
//
// HOW TO USE:
//   1. Fill in CLIENT_ID and CLIENT_SECRET below (from the Google Cloud
//      Console, after creating an OAuth Client ID of type "Desktop app").
//   2. In your terminal, in this folder, run:
//        node get-drive-refresh-token.js
//   3. It will print a long Google URL. Copy that whole URL and paste it
//      into your browser.
//   4. Log in with the Google account you want backups to go to, and
//      click Allow / Continue on the permission screen.
//   5. Your browser will show "Success!" — go back to your terminal.
//   6. Your terminal will print a "refresh token" — copy that whole
//      string and send it to Claude. That's the only thing you need to
//      save from this script; you only ever run this once.
//
// This script never sends anything anywhere except Google's own
// servers - it's just doing the one-time login handshake for you.

const CLIENT_ID = 'PASTE-YOUR-CLIENT-ID-HERE'
const CLIENT_SECRET = 'PASTE-YOUR-CLIENT-SECRET-HERE'
const REDIRECT_URI = 'http://localhost:53682'
const SCOPE = 'https://www.googleapis.com/auth/drive.file'

const http = require('http')

if (CLIENT_ID.startsWith('PASTE-') || CLIENT_SECRET.startsWith('PASTE-')) {
  console.log('\nPlease open this file and fill in CLIENT_ID and CLIENT_SECRET first, then run it again.\n')
  process.exit(1)
}

const authUrl =
  'https://accounts.google.com/o/oauth2/v2/auth' +
  `?client_id=${encodeURIComponent(CLIENT_ID)}` +
  `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}` +
  '&response_type=code' +
  `&scope=${encodeURIComponent(SCOPE)}` +
  '&access_type=offline' +
  '&prompt=consent'

console.log('\n1. Copy this whole URL and open it in your browser:\n')
console.log(authUrl)
console.log('\n2. Log in and click Allow. Then come back here.\n')
console.log('Waiting...\n')

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, REDIRECT_URI)
  const code = url.searchParams.get('code')

  if (!code) {
    res.end('No code received. Close this tab and check the terminal for an error.')
    return
  }

  res.end('<h2>Success! You can close this tab and go back to your terminal.</h2>')
  server.close()

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        redirect_uri: REDIRECT_URI,
        grant_type: 'authorization_code'
      })
    })
    const tokenJson = await tokenRes.json()

    if (tokenJson.refresh_token) {
      console.log('\n✅ SUCCESS! Copy this refresh token and send it to Claude:\n')
      console.log(tokenJson.refresh_token)
      console.log('\n')
    } else {
      console.log('\n❌ Something went wrong. Send this whole message to Claude:\n')
      console.log(JSON.stringify(tokenJson, null, 2))
    }
  } catch (err) {
    console.log('\n❌ Error exchanging code for a token. Send this to Claude:\n', err)
  }
})

server.listen(53682, () => {})
