-- =====================================================================
-- BHD FILMS — MIGRATION 009: Automatic Google Drive backup
-- =====================================================================
-- OPTIONAL, ADVANCED. The instant ANY file is uploaded to one of these
-- private buckets — payment receipts, refund payment proofs, support
-- ticket photos, your payment QR code — a copy is automatically sent
-- to a Google Drive folder you own. Nothing changes for customers or
-- admins; this runs silently in the background.
--
-- BEFORE running this file, you must have already:
--   1. Deployed the backup-to-drive Edge Function:
--        supabase functions deploy backup-to-drive
--   2. Set its 4 Google Drive secrets (client id/secret, refresh token,
--      folder id) — see the setup steps Claude walked you through.
--   3. Enabled the "pg_net" extension (Database -> Extensions) — same
--      one used for push notifications, skip if already on.
--
-- Then replace YOUR-SERVICE-ROLE-KEY below with your project's
-- service_role key (Project Settings -> API), and run this whole file
-- once in the Supabase SQL Editor.
-- =====================================================================

create or replace function public.trg_backup_upload_to_drive()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Only back up files from buckets we actually care about.
  if new.bucket_id not in ('receipts', 'support-attachments', 'refund-receipts', 'payment-qr') then
    return new;
  end if;

  begin
    perform net.http_post(
      url := 'https://zmopoujgltbiegrarvkp.supabase.co/functions/v1/backup-to-drive',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer YOUR-SERVICE-ROLE-KEY'
      ),
      body := jsonb_build_object('bucket', new.bucket_id, 'path', new.name)
    );
  exception when others then
    -- A backup hiccup must NEVER block a real upload (receipt, proof,
    -- QR code) from succeeding.
    null;
  end;

  return new;
end;
$$;

drop trigger if exists trg_storage_backup_to_drive on storage.objects;
create trigger trg_storage_backup_to_drive
  after insert on storage.objects
  for each row execute function public.trg_backup_upload_to_drive();

-- Done! Test it: upload any receipt/photo anywhere in the app, then
-- check your Google Drive folder a few seconds later.
