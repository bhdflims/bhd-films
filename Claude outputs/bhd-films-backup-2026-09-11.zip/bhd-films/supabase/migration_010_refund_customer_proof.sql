-- =====================================================================
-- BHD FILMS — MIGRATION 010: Let customers attach a photo when
-- requesting a refund
-- =====================================================================
-- Adds an optional photo upload to the customer's "Request Refund" form
-- - e.g. a screenshot of their UPI QR code, or their bank details - so
-- admins can see it when deciding how to pay a bank/UPI refund. This is
-- IN ADDITION to the existing text "Reason" box, not a replacement.
-- =====================================================================

-- 1. New column to store the customer's uploaded photo path.
alter table public.refund_requests add column if not exists customer_proof_path text;

-- 2. New private storage bucket - customers upload here themselves
--    (own folder only), only they and admins can view it.
insert into storage.buckets (id, name, public)
values ('refund-customer-proof', 'refund-customer-proof', false)
on conflict (id) do nothing;

drop policy if exists "refund_customer_proof_insert_own_folder" on storage.objects;
create policy "refund_customer_proof_insert_own_folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'refund-customer-proof'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "refund_customer_proof_select_own_or_admin" on storage.objects;
create policy "refund_customer_proof_select_own_or_admin"
on storage.objects for select to authenticated
using (
  bucket_id = 'refund-customer-proof'
  and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
);

-- 3. Replace create_refund_request() with a version that accepts the new
--    optional photo path. The old 2-argument version is dropped first so
--    there's no ambiguity between the two versions.
drop function if exists public.create_refund_request(uuid, text);

create or replace function public.create_refund_request(p_order_id uuid, p_reason text default null, p_customer_proof_path text default null)
returns json
language plpgsql security definer set search_path = public as $$
declare
  v_user uuid := auth.uid();
  v_order public.orders%rowtype;
  v_amount numeric(12,2);
  v_ordered_qty int;
  v_code text;
  v_id uuid;
begin
  if v_user is null then
    raise exception 'You must be logged in.';
  end if;

  select * into v_order from public.orders where id = p_order_id and user_id = v_user for update;
  if v_order is null then
    raise exception 'Order not found.';
  end if;
  if v_order.status not in ('processing','completed') then
    raise exception 'This order is not eligible for a refund request.';
  end if;
  if exists (select 1 from public.refund_requests where order_id = p_order_id and status = 'pending') then
    raise exception 'A refund request for this order is already pending.';
  end if;
  if p_customer_proof_path is not null and split_part(p_customer_proof_path, '/', 1) <> v_user::text then
    raise exception 'Invalid proof photo.';
  end if;

  v_amount := greatest(v_order.grand_total - coalesce(v_order.discount_amount, 0), 0);
  select coalesce(sum(quantity), 0) into v_ordered_qty from public.order_items where order_id = p_order_id;

  v_code := public.generate_code('RF');

  insert into public.refund_requests (request_code, order_id, user_id, amount, ordered_quantity, reason, customer_proof_path, status)
  values (v_code, p_order_id, v_user, v_amount, v_ordered_qty, nullif(trim(coalesce(p_reason, '')), ''), nullif(trim(coalesce(p_customer_proof_path, '')), ''), 'pending')
  returning id into v_id;

  return json_build_object('id', v_id, 'request_code', v_code, 'amount', v_amount);
end;
$$;

grant execute on function public.create_refund_request(uuid, text, text) to authenticated;

-- Done! Customers will now see an optional photo-upload field on the
-- "Request Refund" form, and admins will see a "View Customer's Photo"
-- button on any request that includes one.
