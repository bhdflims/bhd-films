-- =====================================================================
-- BHD FILMS — MIGRATION 008: Refund system
-- =====================================================================
-- What this adds:
--   1. A "refund_requests" table — one row per refund request a customer
--      submits, tied to one of their orders.
--   2. Customers can only ever request "Refund to Wallet" — that's the
--      only option they see.
--   3. Admins review each request and can approve it EITHER way:
--        - "Wallet"  -> instantly credits the customer's wallet.
--        - "Bank/UPI" -> admin manually pays the customer outside the
--          app, then uploads a photo/screenshot as proof. The customer
--          can see that proof. The wallet is NOT touched in this case.
--      Or admins can reject the request with a remark.
--   4. Admins can type in how much of the service was actually
--      delivered (e.g. 80 out of 100 followers) and the system shows a
--      plain "Eligible" / "Not Eligible" hint based on your 80% rule —
--      but the final decision always stays with the admin.
--   5. A new storage bucket ("refund-receipts") to hold the proof-of-
--      payment photos admins upload for bank/UPI refunds.
--   6. Optional: if you already set up Migration 007 (admin push
--      notifications), a new refund request will also push-notify you.
--      If you haven't, this still works fine — it just won't push
--      anything (nothing breaks either way).
--
-- Safe to run more than once. Run this whole file in the Supabase SQL
-- Editor as a NEW query.
-- =====================================================================

-- 1. The table -----------------------------------------------------

create table if not exists public.refund_requests (
  id uuid primary key default gen_random_uuid(),
  request_code text not null unique,
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null,
  ordered_quantity int,
  delivered_quantity int,
  reason text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  resolution_method text check (resolution_method in ('wallet','bank')),
  receipt_path text,
  admin_remark text,
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_refund_requests_user on public.refund_requests (user_id, created_at desc);
create index if not exists idx_refund_requests_order on public.refund_requests (order_id);
create index if not exists idx_refund_requests_pending on public.refund_requests (status) where status = 'pending';

alter table public.refund_requests enable row level security;

drop policy if exists "refund_requests_select" on public.refund_requests;
create policy "refund_requests_select" on public.refund_requests
  for select using (user_id = auth.uid() or public.is_admin());

drop trigger if exists trg_refund_requests_updated on public.refund_requests;
create trigger trg_refund_requests_updated
  before update on public.refund_requests
  for each row execute function public.set_updated_at();

-- 2. Storage bucket for admin-uploaded proof-of-payment photos -----

insert into storage.buckets (id, name, public)
values ('refund-receipts', 'refund-receipts', false)
on conflict (id) do nothing;

drop policy if exists "refund_receipts_insert_admin" on storage.objects;
create policy "refund_receipts_insert_admin" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'refund-receipts'
  and public.is_admin()
);

drop policy if exists "refund_receipts_select_own_or_admin" on storage.objects;
create policy "refund_receipts_select_own_or_admin" on storage.objects
for select to authenticated
using (
  bucket_id = 'refund-receipts'
  and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin())
);

-- 3. Refunds require admin/super_admin — never assignable to staff,
--    same sensitivity level as wallets/rates/payment settings.
create or replace function public.has_permission(perm text)
returns boolean
language plpgsql stable security definer set search_path = public as $$
declare
  v_role text;
  v_perms jsonb;
  v_restricted text[] := array['manage_wallets','manage_rates','manage_bulk_pricing','manage_payment_settings','manage_admins','manage_refunds'];
begin
  select role, permissions into v_role, v_perms from public.admin_users where id = auth.uid();
  if v_role is null then
    return false;
  end if;
  if v_role = 'super_admin' then
    return true;
  end if;
  if v_role = 'admin' then
    return perm <> 'manage_admins';
  end if;
  if v_role = 'staff' then
    if perm = any(v_restricted) then
      return false;
    end if;
    return coalesce((v_perms ->> perm)::boolean, false);
  end if;
  return false;
end;
$$;

-- 4. Customer creates a refund request (wallet-only, always) -------

create or replace function public.create_refund_request(p_order_id uuid, p_reason text default null)
returns json
language plpgsql security definer set search_path = public as $$
declare
  v_user uuid := auth.uid();
  v_order public.orders%rowtype;
  v_amount numeric(12,2);
  v_ordered_qty int;
  v_code text;
  v_id uuid;
begin
  if v_user is null then
    raise exception 'You must be logged in.';
  end if;

  select * into v_order from public.orders where id = p_order_id and user_id = v_user for update;
  if v_order is null then
    raise exception 'Order not found.';
  end if;
  if v_order.status not in ('processing','completed') then
    raise exception 'This order is not eligible for a refund request.';
  end if;
  if exists (select 1 from public.refund_requests where order_id = p_order_id and status = 'pending') then
    raise exception 'A refund request for this order is already pending.';
  end if;

  v_amount := greatest(v_order.grand_total - coalesce(v_order.discount_amount, 0), 0);
  select coalesce(sum(quantity), 0) into v_ordered_qty from public.order_items where order_id = p_order_id;

  v_code := public.generate_code('RF');

  insert into public.refund_requests (request_code, order_id, user_id, amount, ordered_quantity, reason, status)
  values (v_code, p_order_id, v_user, v_amount, v_ordered_qty, nullif(trim(coalesce(p_reason, '')), ''), 'pending')
  returning id into v_id;

  return json_build_object('id', v_id, 'request_code', v_code, 'amount', v_amount);
end;
$$;

grant execute on function public.create_refund_request(uuid, text) to authenticated;

-- 5. Admin approves (wallet or bank) or rejects ---------------------

create or replace function public.admin_review_refund_request(
  p_refund_request_id uuid,
  p_action text,
  p_remark text default null,
  p_resolution_method text default null,
  p_receipt_path text default null,
  p_delivered_quantity int default null
)
returns json
language plpgsql security definer set search_path = public as $$
declare
  v_admin uuid := auth.uid();
  v_rr public.refund_requests%rowtype;
  v_wallet public.wallets%rowtype;
  v_before numeric;
  v_after numeric;
  v_final_remark text;
begin
  if not public.has_permission('manage_refunds') then
    raise exception 'Not authorized.';
  end if;
  if p_action not in ('approve','reject') then
    raise exception 'Invalid action.';
  end if;

  select * into v_rr from public.refund_requests where id = p_refund_request_id for update;
  if v_rr is null then
    raise exception 'Refund request not found.';
  end if;
  if v_rr.status <> 'pending' then
    raise exception 'This request has already been reviewed.';
  end if;

  if p_action = 'approve' then
    if p_resolution_method not in ('wallet','bank') then
      raise exception 'Choose how this refund was paid: wallet or bank.';
    end if;
    if p_resolution_method = 'bank' and (p_receipt_path is null or length(trim(p_receipt_path)) = 0) then
      raise exception 'Upload proof of payment before marking this as paid via bank/UPI.';
    end if;

    if p_resolution_method = 'wallet' then
      select * into v_wallet from public.wallets where user_id = v_rr.user_id for update;
      if v_wallet is null then
        raise exception 'Wallet not found for this customer.';
      end if;
      v_before := v_wallet.available_fund;
      v_after := v_before + v_rr.amount;
      v_final_remark := coalesce(nullif(trim(p_remark), ''), 'Refund has been added to your wallet.');

      update public.wallets
      set available_fund = v_after, updated_at = now()
      where id = v_wallet.id;

      insert into public.wallet_transactions (wallet_id, user_id, type, amount, balance_before, balance_after, status, remark, related_order_id, created_by_admin_id)
      values (v_wallet.id, v_rr.user_id, 'refund', v_rr.amount, v_before, v_after, 'completed', v_final_remark, v_rr.order_id, v_admin);
    else
      v_final_remark := coalesce(nullif(trim(p_remark), ''), 'Refund has been paid to your bank/UPI. See receipt for proof.');
    end if;

    update public.refund_requests
    set status = 'approved', resolution_method = p_resolution_method, receipt_path = p_receipt_path,
        delivered_quantity = p_delivered_quantity, admin_remark = v_final_remark,
        reviewed_by = v_admin, reviewed_at = now(), updated_at = now()
    where id = v_rr.id;

    update public.orders set status = 'refunded', updated_at = now() where id = v_rr.order_id;

    insert into public.notifications (user_id, title, message, type, related_id)
    values (v_rr.user_id, 'Refund Approved',
      v_final_remark || ' Amount: ' || to_char(v_rr.amount, 'FM999999990'), 'refund_request', v_rr.id);

    perform public.write_audit_log('refund_approved', 'refund_request', v_rr.id::text,
      jsonb_build_object('status', v_rr.status),
      jsonb_build_object('status', 'approved', 'method', p_resolution_method, 'amount', v_rr.amount),
      v_final_remark);

  else -- reject
    v_final_remark := coalesce(nullif(trim(p_remark), ''), 'This refund request was not approved.');
    update public.refund_requests
    set status = 'rejected', delivered_quantity = p_delivered_quantity, admin_remark = v_final_remark,
        reviewed_by = v_admin, reviewed_at = now(), updated_at = now()
    where id = v_rr.id;

    insert into public.notifications (user_id, title, message, type, related_id)
    values (v_rr.user_id, 'Refund Request Rejected', v_final_remark, 'refund_request', v_rr.id);

    perform public.write_audit_log('refund_rejected', 'refund_request', v_rr.id::text,
      jsonb_build_object('status', v_rr.status), jsonb_build_object('status', 'rejected'), v_final_remark);
  end if;

  return json_build_object('status', 'ok');
end;
$$;

grant execute on function public.admin_review_refund_request(uuid, text, text, text, text, int) to authenticated;

-- 6. Optional: push-notify admins on a new refund request. Safe even
--    if Migration 007 / notify_admins() was never set up — it just
--    quietly does nothing instead of erroring.
create or replace function public.trg_notify_admin_new_refund()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  begin
    perform public.notify_admins(
      'New Refund Request 💸',
      'Order refund requested — ₹' || to_char(new.amount, 'FM999999990') || ' (' || new.request_code || ').',
      '/admin/refunds'
    );
  exception when others then
    null;
  end;
  return new;
end;
$$;

drop trigger if exists trg_refund_requests_notify_admin on public.refund_requests;
create trigger trg_refund_requests_notify_admin
  after insert on public.refund_requests
  for each row execute function public.trg_notify_admin_new_refund();

-- Done! Refund requests are ready. Next: redeploy the frontend code
-- for the new Refund pages, then add "Refunds" access to any staff
-- admins you want reviewing them via Admin Users (only Admin /
-- Super Admin roles can review refunds, by design).
