-- =====================================================================
-- BHD FILMS — MIGRATION 007: Push notifications for admins
-- =====================================================================
-- OPTIONAL, ADVANCED. Once this is set up, the moment a new order comes
-- in, or a customer sends a new support message, every admin who has
-- "Enable Notifications" turned on will get a push alert straight to
-- their phone/browser — even if the BHD Films tab isn't open.
--
-- BEFORE running this file, do these 3 things:
--   1. Redeploy the send-push Edge Function (it was just updated to
--      support this). In your terminal, in the project folder, run:
--        supabase functions deploy send-push
--   2. In the Supabase Dashboard, go to Database -> Extensions and make
--      sure "pg_net" is switched ON. (Skip this if you already turned it
--      on before, e.g. for the optional "Good Morning" cron job.)
--   3. Get your project's service_role key: Project Settings -> API ->
--      Project API keys -> service_role (click reveal, then copy it).
--      Treat this key like a password — never share it or put it in your
--      website code. It's only safe to paste into this SQL file because
--      this file only ever runs once, privately, in your own Supabase
--      SQL Editor.
--
-- Then, below, replace YOUR-SERVICE-ROLE-KEY with the service_role key
-- you copied in step 3, then run this whole file once in the Supabase
-- SQL Editor. (Your project's URL is already filled in below.)
-- =====================================================================

create or replace function public.notify_admins(p_title text, p_body text, p_url text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  perform net.http_post(
    url := 'https://zmopoujgltbiegrarvkp.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer YOUR-SERVICE-ROLE-KEY'
    ),
    body := jsonb_build_object(
      'title', p_title,
      'body', p_body,
      'url', p_url,
      'audience', 'admins'
    )
  );
exception when others then
  -- A notification hiccup (e.g. pg_net not enabled yet) must NEVER
  -- block a real order or support message from being saved.
  null;
end;
$$;

-- 1. A new order comes in -> ping every admin with notifications on.
create or replace function public.trg_notify_admin_new_order()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.notify_admins(
    'New Order 🛒',
    'Order ' || new.order_code || ' — ₹' || to_char(new.grand_total, 'FM999999990') || ' received.',
    '/admin/orders'
  );
  return new;
end;
$$;

drop trigger if exists trg_orders_notify_admin on public.orders;
create trigger trg_orders_notify_admin
  after insert on public.orders
  for each row execute function public.trg_notify_admin_new_order();

-- 2. A customer sends a new support message -> ping every admin.
create or replace function public.trg_notify_admin_new_support_msg()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.sender_type = 'customer' then
    perform public.notify_admins(
      'New Support Message 💬',
      left(coalesce(new.message, ''), 120),
      '/admin/support'
    );
  end if;
  return new;
end;
$$;

drop trigger if exists trg_support_messages_notify_admin on public.support_messages;
create trigger trg_support_messages_notify_admin
  after insert on public.support_messages
  for each row execute function public.trg_notify_admin_new_support_msg();

-- Done! Test it: place a real order (or ask a customer test account to),
-- and check that an admin device with notifications enabled gets a push
-- alert within a few seconds.
