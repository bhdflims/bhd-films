-- =====================================================================
-- BHD FILMS — Daily full database backup to Google Drive
-- =====================================================================
-- Schedules a job, run entirely inside your Supabase database, that
-- calls the backup-database Edge Function once a day. It exports every
-- important table (customers, orders, wallet transactions, coupons,
-- refunds, support tickets, and more) as CSV files and uploads them
-- straight into your Google Drive backup folder - one dated file per
-- table, every day.
--
-- BEFORE running this file:
--   1. Deploy the backup-database function:
--        supabase functions deploy backup-database
--   2. Make sure you've already set the 4 Google Drive secrets (same
--      ones used for backup-to-drive).
--   3. Go to Database -> Extensions and make sure BOTH "pg_cron" and
--      "pg_net" are enabled (skip if already on from earlier setup).
--   4. Get your service_role key: Project Settings -> API.
--
-- Replace YOUR-SERVICE-ROLE-KEY below, then run this whole file once.
-- =====================================================================

select
  cron.schedule(
    'bhd-films-database-backup',
    '30 2 * * *',  -- 02:30 UTC every day - edit to taste (cron syntax, UTC time)
    $$
    select net.http_post(
      url := 'https://zmopoujgltbiegrarvkp.supabase.co/functions/v1/backup-database',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer YOUR-SERVICE-ROLE-KEY'
      ),
      body := '{}'::jsonb
    );
    $$
  );

-- To see scheduled jobs:      select * from cron.job;
-- To see recent run history:  select * from cron.job_run_details order by start_time desc limit 20;
-- To remove this job:         select cron.unschedule('bhd-films-database-backup');
-- To run it immediately as a one-off test (instead of waiting for
-- 02:30 UTC), run the "select net.http_post(...)" block above by
-- itself, without the cron.schedule(...) wrapper.
